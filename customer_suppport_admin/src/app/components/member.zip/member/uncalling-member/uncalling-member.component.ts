import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ToastrManager } from 'ng6-toastr-notifications';
import * as service from '../../../shared/service/index';
declare const $: any;

import { EmailPatternValidator } from '../../../shared/all-pattern/email-pattern-validator';
import { PasswordPatternValidator } from '../../../shared/all-pattern/password-pattern-validator';
import { UserIdPatternValidator } from '../../../shared/all-pattern/userid-pattern-validator';
import { NamePatternValidator } from '../../../shared/all-pattern/name-pattern-validator';
import { MobilePatternValidator } from '../../../shared/all-pattern/mobile-pattern-validator';


@Component({
    selector: 'app-uncalling-member',
    templateUrl: './uncalling-member.component.html',
})
export class UncallingMemberComponent implements OnInit {
 
   public updateUserForm: FormGroup;
   public singleUserData = {};
   public submitted:boolean=false;
   public regData: any;

  public start = 0;
  public itemsTotal;
  public page: number = 1;
  public data:any;
  public length:number = 50;
  public tabledata={};
  public flag:boolean=false;
  public tableview = {};
 
    constructor(private formBuilder: FormBuilder,
                private api: service.ApiService,
                private tokenService: service.TokenService,
                private router: Router,
                private toastr: ToastrManager,
                private tokenExpService: service.TokenExpiryService,
                public commonServe: service.CommonService) {}
    ngOnInit() {
        
        this.tabledata['start'] = 0;
        this.tabledata['length'] = 50;
        this.loadData();
        this.createForm();
    }
 get f() { return this.updateUserForm.controls; }
    private createForm() {
        this.updateUserForm = this.formBuilder.group({
            email: new FormControl('', [Validators.required,EmailPatternValidator(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
            name: new FormControl('', [Validators.required, NamePatternValidator(/^[-_a-zA-Z]+(\s+[-_a-zA-Z]+)*$/)]),
            mobile: new FormControl('', [Validators.required, MobilePatternValidator(/^(?=.*[0-9]).{8,12}$/)]),
            password: ['', Validators.required],
        });
    }
    
    public loadData(){
  

       this.api.get('/admin/allusercount').subscribe(data=>{
       // this.api.post('/secure/getdailytradingprofit',this.tabledata).subscribe(data=>{
          this.tabledata['records'] = ''; 
          let rec = [];
            if(data.status == 1 || data.status == 'success'){
              this.tableview['failmessage'] = '';
              this.tabledata['recordsTotal'] = data.totalrows;
             
              this.tabledata['headers'] = Object.keys(data.data[0]);
               for (let i = 0; i < data.data.length; i++) {
                    rec.push(Object.values(data.data[i]));
                }
                this.tabledata['records'] = rec;
                console.log(this.tabledata['records']);
                this.tableview['success'] = this.tabledata;
               
            }  
            else if(data.status == 0){
                this.tabledata['recordsTotal'] = 0;
              this.tableview['failmessage'] = 'No Records Found';
            }
       });
    }

    public onPageChange(event) {
        this.tabledata['start'] = (event * 10) - 10;
        this.loadData();
    }

    public changeStatus(status,id){
        var obj={
            'status':status,
            'id':id
        }

            this.api.post('/admin/changeuserstatus',obj).subscribe(data => {
                if(data.status == 'success'){
                    this.toastr.successToastr(data.data, 'Success!');
                   this.loadData();
                }else{
                 this.toastr.successToastr(data.data, 'Error!');
                }
              //this.dashboarddata['allusercount'] = data.recordsTotal;
          }, err => {
            this.tokenExpService.isTokenValid();
          });

    }
     public deleteUser(active,id){
        var obj={
            'active':active,
            'id':id
        }

           this.api.post('/admin/deleteuser',obj).subscribe(data => {
                if(data.status == 'success'){
                    this.toastr.successToastr(data.data, 'Success!');
                   this.loadData();
                }else{
                 this.toastr.successToastr(data.data, 'Error!');
                }
              //this.dashboarddata['allusercount'] = data.recordsTotal;
          }, err => {
            this.tokenExpService.isTokenValid();
          });

    }

    public edutUser(userid){
         var obj={
            'id':userid
        }
        this.api.post('/admin/viewsingleuser',obj).subscribe(data => {
                if(data.status == 'success')
                {
                    this.singleUserData['singledata'] = data.data[0];
                   $('#editUser').modal('show');
               
                
                }else{
                 this.toastr.successToastr(data.data, 'Error!');
                }
              //this.dashboarddata['allusercount'] = data.recordsTotal;
          }, err => {
            this.tokenExpService.isTokenValid();
          });
    }

   public onUpdate() {
    this.submitted = true;
    let data = this.updateUserForm.value;
  
      if (this.updateUserForm.invalid ) {
        return;
      } else
      {
            //$('#loader').show();
           this.regData = { 
               'id' :this.singleUserData['singledata']['id'],  
               'email': data.email,
                'fname': data.name,
               'password': data.password,
                'mobile': data.mobile.toString(),
           }
          
            this.api.post('/admin/updateuser', this.regData).subscribe(result => {
                if (result.status === 'success')
                 {
                   $('#loader').hide();
                    this.toastr.successToastr(result.data, 'Success!');
                    $('#editUser').modal('hide');
                      this.loadData();

                } else {
                  $('#loader').hide();
                 this.toastr.errorToastr(result.data, 'Error!');
                }
            }, error => {
                $('#loader').hide();
                this.toastr.errorToastr('Internal Earror', 'Error!');
              });
          }
      }
    

}
