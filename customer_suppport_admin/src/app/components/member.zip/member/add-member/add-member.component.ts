import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ToastrManager } from 'ng6-toastr-notifications';
import * as service from '../../../shared/service/index';
declare const $: any;

import { EmailPatternValidator } from '../../../shared/all-pattern/email-pattern-validator';
import { PasswordPatternValidator } from '../../../shared/all-pattern/password-pattern-validator';
import { UserIdPatternValidator } from '../../../shared/all-pattern/userid-pattern-validator';
import { NamePatternValidator } from '../../../shared/all-pattern/name-pattern-validator';
import { MobilePatternValidator } from '../../../shared/all-pattern/mobile-pattern-validator';
import {formatDate } from '@angular/common';

@Component({
    selector: 'app-add-member',
    templateUrl: './add-member.component.html',
})
export class AddMemberComponent implements OnInit {
 
  public personal_information: FormGroup;
  public currentDate;
  public member_positions:string;
  public submitted:boolean=false;
  public clientid;


  public countryArray =[];
  public countrykeyword;
  public selectedCountry;
  public selectedCountryFlag:boolean=false;

  public stateArray =[];
  public statekeyword;
  public selectedState;
  public selectedStateFlag:boolean=false;

  public cityArray =[];
  public citykeyword;
  public selectedCity;
  public selectedCityFlag:boolean=false;

  public interactionmethod =[];
  public selutionValue='Mr.';

  public referenceVal = '2';
  public interctionVal = '';


  public persons = [];
  


// keyword = 'name';
//   data1 = 
//   [
//      {
//        id: 1,
//        name: 'Usa'
//      },
//      {
//        id: 2,
//        name: 'England'
//      }
//   ];


    constructor(private formBuilder: FormBuilder,
                private api: service.ApiService,
                private tokenService: service.TokenService,
                private router: Router,
                private toastr: ToastrManager,
                private tokenExpService: service.TokenExpiryService,
                public commonServe: service.CommonService) {


    }
    ngOnInit() {
        this.selectedCountry = '';
        this.selectedState = '';
        this.selectedCity = '';
        this.currentDate = formatDate(new Date(), 'dd/MM/yyyy', 'en-US', '+0530');
         this.clientid = '10001';
        this.member_positions = '0';
        this.createForm();
        this.searchCountry();
 }
 get f() { return this.personal_information.controls; }
    
    private createForm() {
        this.personal_information = this.formBuilder.group({
            clientid: [''],
            member_name: ['',[Validators.required]],
            city: [''],
            currentdate: [''],
            country: [''],
            pin: [''],
            company_name: [''],
            phone_number: [''],
            address: [''],
            demo_link: [''],
            state:[''],
           
            email: new FormControl('', [Validators.required,EmailPatternValidator(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
            mobile: new FormControl('', [Validators.required, MobilePatternValidator(/^(?=.*[0-9]).{8,12}$/)]),
            
        });
    }
    
 public searchCountry(){
     
     this.api.get('/secure/get-all-country-state-district').subscribe(data => {
        if ((data.status == 'success') || (data.status == 1)) {
           $('#loader').hide();
           this.countryArray = data.country;
           this.countrykeyword = 'countryname';

           this.stateArray = data.state;
           this.statekeyword = 'state';

           this.cityArray = data.district;
           this.citykeyword = 'district';

           this.interactionmethod = data.interactionmethod;
          
        } else {
          $('#loader').hide();
         
        }
      }, err => {
         $('#loader').hide();
        this.router.navigateByUrl('/something-wrong');
      });

 }   
 
  public onChangeSearchCountry(val: string) {
    var newCountry = this.countryArray.find(tree => tree.countryname.toLowerCase().startsWith(val));
    if(newCountry == undefined){
       this.selectedCountryFlag = true;
        this.selectedCountry = ''; 
     }else{
       this.selectedCountry = val; 
     }
  }

  public selectEventCountry(item) {
   this.selectedCountry =item.countryname;
   }


  public onChangeSearchState(val: string) {
      var newState = this.stateArray.find(tree => tree.state.toLowerCase().startsWith(val));
      if(newState == undefined){
         this.selectedStateFlag = true;
          this.selectedState = ''; 
       }else{
         this.selectedState = val; 
       }
   }

  public selectEventState(item) {
   this.selectedState = item.state;
   }
  


  public onChangeSearchCity(val: string) {
      var newCity = this.cityArray.find(tree => tree.district.toLowerCase().startsWith(val));
      if(newCity == undefined){
         this.selectedCityFlag = true;
          this.selectedCity = ''; 
       }else{
         this.selectedCity = val; 
       }
   }

  public selectEventCity(item) {
     this.selectedState = item.district;
   }
  

public changeSalution(salvalue){
  if(salvalue){
    this.selutionValue = salvalue; 
  }
}
public selectReference(salrefe){
  if(salrefe){
    this.referenceVal = salrefe; 
  }
}

public changeInterction(interctionval){
  if(interctionval){
    this.interctionVal = interctionval;
  }
}

   public onSubmit(){
    
      this.submitted = true;
       let data = this.personal_information.value;
        if (this.personal_information.invalid ) {
            return;
        } else {
          if(this.selectedCountryFlag && this.selectedCountry==''){
             this.toastr.errorToastr('Please select  country from the list', 'Error');
           }else if(this.selectedStateFlag && this.selectedState==''){
             this.toastr.errorToastr('Please select state from the list', 'Error');
          }else if(this.selectedCityFlag && this.selectedCity==''){
            this.toastr.errorToastr('Please select city from the list', 'Error');
           }else{
               var obj={
                'clientid':this.clientid,
                'currentdate':this.currentDate,
                'company_name':data.company_name,
                'salvalue':this.selutionValue,
                'member_name':data.member_name,
                'email':data.email,
                'phone_number':data.phone_number,
                'mobile':data.mobile,
                'country':this.selectedCountry,
                'state':this.selectedState,
                'city':this.selectedCity,
                'pin':data.pin,
                'address':data.address,
                'reference_by':this.referenceVal,
                'interction_method':this.interctionVal,
                'demo_link':data.demo_link
             }
            console.log(obj);
           }
          
        }
   }
   

    
    

}
