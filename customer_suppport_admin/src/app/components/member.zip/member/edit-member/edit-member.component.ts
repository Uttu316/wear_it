import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ToastrManager } from 'ng6-toastr-notifications';
import * as service from '../../../shared/service/index';
declare const $: any;

import { EmailPatternValidator } from '../../../shared/all-pattern/email-pattern-validator';
import { PasswordPatternValidator } from '../../../shared/all-pattern/password-pattern-validator';
import { UserIdPatternValidator } from '../../../shared/all-pattern/userid-pattern-validator';
import { NamePatternValidator } from '../../../shared/all-pattern/name-pattern-validator';
import { MobilePatternValidator } from '../../../shared/all-pattern/mobile-pattern-validator';
import {formatDate } from '@angular/common';

@Component({
    selector: 'app-edit-member',
    templateUrl: './edit-member.component.html',
})
export class EditMemberComponent implements OnInit {
 
  public personal_information: FormGroup;
  public currentDate;
  public member_positions:string;
  public submitted:boolean=false;
  public clientid;
  
    constructor(private formBuilder: FormBuilder,
                private api: service.ApiService,
                private tokenService: service.TokenService,
                private router: Router,
                private toastr: ToastrManager,
                private tokenExpService: service.TokenExpiryService,
                public commonServe: service.CommonService) {


    }
    ngOnInit() {
        this.currentDate = formatDate(new Date(), 'dd/MM/yyyy', 'en-US', '+0530');
         this.clientid = '10001';
        this.member_positions = '0';
         this.createForm();
    }
 get f() { return this.personal_information.controls; }
    
    private createForm() {
        this.personal_information = this.formBuilder.group({
            clientid: [''],
            member_name: [''],
            city: [''],
            currentdate: [''],
            country: [''],
            pin: [''],
            company_name: [''],
            phone_number: [''],
            address: [''],
            demo_link: [''],
            state:[''],
           
            email: new FormControl('', [Validators.required,EmailPatternValidator(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
            mobile: new FormControl('', [Validators.required, MobilePatternValidator(/^(?=.*[0-9]).{8,12}$/)]),
            
        });
    }
    
    
  

   public onSubmit(){
     alert();
      this.submitted = true;
       let data = this.personal_information.value;
        if (this.personal_information.invalid ) {
            return;
        } else {
          console.log(this.personal_information.value);
        }
   }
   

    
    

}
